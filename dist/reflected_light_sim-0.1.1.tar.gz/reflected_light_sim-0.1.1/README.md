# reflected-light-sim
Calculates reflected light from a planet given a stellar PHOENIX model and planet albedo (developed as part of the 2023 CodeAstro workshop).\
![Code Astro](https://img.shields.io/badge/Made%20at-Code/Astro-blueviolet.svg)
## Simulation Flowchart
![Flowchart](https://github.com/jlibermann/reflected-light-sim/blob/add-the-docs/codeastroflowchart.png)
